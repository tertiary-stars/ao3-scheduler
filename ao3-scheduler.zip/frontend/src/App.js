import SchedulerPage from "./pages/SchedulerPage";

function App() {
  return <SchedulerPage />;
}

export default App;
